<div class="white section-content">
	<div class="container">
        		
        <!--<h3 class="header center-align grey-text darken-2 margin-height-60">Increase your organic mobile app installs</h3>-->
        
        <div class="row">
            <div class="col m6 s12">
            	<img src="http://placehold.it/450x250?text=Comparison+graph" class="responsive-img" alt="Graph">
            </div>
            
            <div class="col m6 s12">
            	<ol>
                	<li>Mobile app installs have on average over 3 times higher lifetime value than mobile web visitors. Due to higher retention and engagement</li>
                	<li>The problem is, mobile user acquisition (UA) is usually rather costly. The average CPI is now over 2USD in many European countries and the USA. The other option is to increase your organic installs</li>
                	<li>Installify helps you  increase your organic installs by creating cross-platform and cross-browser smartbanners with just a few clicks</li>
                </ol>
            </div>
        </div>
		
        <div class="margin-height-40"></div>
    </div>
</div>

<div class="container white">
    <div class="divider"></div>
</div>