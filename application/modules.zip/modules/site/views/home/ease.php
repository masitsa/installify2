<div class="white section-content">
	<div class="container">
        
        <!--<h3 class="header center-align grey-text darken-2 margin-height-60">Create a smartbanner in under 5 minutes</h3>-->
        
        <div class="row">
            
            <div class="col m6">
            	<ol>
                	<li>Type in the site or page where you want banner to appear</li>
                	<li>Fill in various setup and customization options</li>
                	<li>Insert Javascript embed code into the page</li>
                </ol>
                
                <p>Enjoy the free installs</p>
            </div>
            
            <div class="col m6">
            	<img src="<?php echo base_url().'assets/img/macbook-editting.png';?>" class="responsive-img" alt="macbook">
            </div>
        </div>
        
        <div class="margin-height-60"></div>
    </div>
</div>

<div class="container white">
    <div class="divider"></div>
</div>